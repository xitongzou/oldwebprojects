A simple concept: I switched the gravity for all the normal Liero weapons. If you get any ideas from it, good for you! Use 'em. They're yours.

4IF