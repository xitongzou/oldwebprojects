Thanx a lot for downloading the Generally Psychotic Weapon Pack (or GPWP, for short).
*WARNING!:* The GPWP should not be used while playing under 100% health! I suggest 750%-2500% health, or for long games, 5000%-10000%.

Anyway. Here is a brief description of the 40 weapons in the GPWP:

* = Very dangerous.

Hoppergrenade: Ya fire it, it bounces. Sounds simple? It isn't. Get hit by one, and you'll have to dodge fifteen Grasshoppers on their way out.

Bloodrocket: Slightly more powerful than the normal Missile, but this one spews blood as it flies.

Buster Ball: A Spikeball that explodes in midair, unleashing some nasty debris.

Blaster Box: Essentially a Booby Trap, but instead of just exploding, it launches Napalm fireballs.

Bubble Bomb: Shoot this one, and it will slowly float up. If it gets hit, it will pop, and spray little bubble bits. Good for hitting someone on their way down, or someone slightly around the corner.

Butcher One: For "decoration". A piece of 1P's worm will fly across the arena, dropping more pieces as it flies and crashes.

Butcher Two: Same thing as Butcher One, but with 2P's worm pieces.

Sparx: A floating Crackler that launches Napalm fireballs instead of particles.

Fire Bullet: One of my personal favourites. A bullet set on fire as it screams out of your gun. If it hits something (other than a worm) it may ricochet a short distance.

Dual Fireball: A pair of larger fire bullets with Napalm fireballs shot from them.

Gammer: Nuke missile. Simple as that.

Cadaverus: Same as the Blaster Box, but more discreet. Comes in a Mine form.

Inferno: A flamethrower that shoots flames that don't disappear when they hit something. Instead, they fall to the ground, lighting it on fire for a while. Don't get burned!

*Suicide: Fires Hellraider bullets in every direction... around you. Good as a kamikaze weapon, or as a last-ditch effort to keep the other guy from killing you.

New Crackler: Slightly weaker than the Sparx, but with faster loading times, the New Crackler floats in the air, shooting out particles.

Lots of Dirt: A fire bullet is shot, but you end up with a stream of dirt. Cool effect at the end, though... looks like the bullet is in an oven, or something.

Mega Punch: Close-range attack. Whack your opponent across the arena!

Mini Rockets: Shoots a rapid fire barrage of mini rockets.

*Missile Swarm: Ooh, this one's fun on 0% loading times. If not, this fires 25 missiles at once. The missiles are slightly weaker than mini rockets.

Nailgun: Standard chaingun filled with nails.

Nuke Launcher: Remember what comes out of Big Nuke bombs? That's right, the actual nukes themselves. That's what this thing shoots.

Pepper Spray: I don't know why I came up with this one. A very weak weapon. Fires a steady stream of mace at the other guy.

Power Fan: This one's cool. A radioactive fan blows away bullets, and can actually hurt your opponent if you get close enough.

*Raider Zero: A Crackler that shoots Hellraider bullets. A dangerous combination indeed.

Napalm X: Looks like a flying aimer thingy. Explodes like a super napalm. More fireballs.

Bomb Shotgun: Standard shotgun filled with explosives. Fun!

Shrapnel Gun: Fires non-exploding-on-contact clusterbomb pieces. Another doofy weapon.

Nuke Fireball: Like the dual fireball, but this only fires one, and it sprays nukes instead of napalm fireballs.

*GOD Bullet: GOD stands for Gun Of Death. Fires a single bullet, but it's enough to kill someone at 100% health in one hit.

Slash Blade: Close-range attack. Slices your opponent with a sword. No recoil, but good damage. However, I suggest Mega Punch if you're that close.

Spraypaint: Fun weapon, for "decoration". Sprays blood where you aim it. Also pushes your enemy right back to the wall.

RF Shotgun: Rapid-fire, 20-bullet shotgun. Enough said.

*Mega Fireball: THE ultimate weapon. Launches a large fireball that can reduce 10000% health to 0% in a second flat with a direct hit.

Super Gatling: An upgraded chaingun. These bullets make big BANGs on impact.

Super Laser: An upgraded laser. Bigger holes. And... *gasp*... it glows!

Teleportation: Fires a teleportation cell that bounces around at super speed, then disappears. However, if you touch a Teleport Star (I'll let you figure that one out for yourselves), and it's far enough out of the ground, you will be zipped to some other part of the arena.

Throw Blade: A lobbing blade. Good for when they're across a wall, and you need to toss something over. This one will definitely cut 'em up!

Triad Gatling: Fires Chaingun bullets that split into threes.

Cluster Fake: Need to clear a room? Or just wanna scare the other guy? Toss this into the same room with him. He'll run like crazy. Meanwhile, you'll be laughing because all it did was pop into a little Greenball.

Wallmaker: A handy-dandy defense weapon. Fires a cluster of dirt bullets, that will explode and turn into a square of dirt.

If you have questions, comments, suggestions about what I can do in my next weapon pack, e-mail me at foureyefalcon@hotmail.com. Thanks!

Other than that, this weapon pack is (C) 4I Falcon, 2001, so don't steal anything unless ya tell me first, by mailing me at the above address.

---------------------------------------------

4IF