War Zone Weapons Pack
BY: Jayson Gumm
DATE: 4/11/01
WEAPONS INCLUED:

55  MM
AK 47
C4
Cross Bow
Plasma
PP7
Timed Mine
Jet Pack

CONTACTING ME:
lierowarzone@hotmail.com

MY SITE:
Liero War Zone
http://lierowarzone.cjb.net

Thanks for downloading Liero War Zone Weapons Pack.