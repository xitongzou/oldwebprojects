       
    ******************************************************************************************
    *   ____     ____     ____         ______             ______         _____        _____  * 
    *  |    |   /    /   |    |       /      \           /      \        \    \      /    /  *
    *  |    |  /    /    |    |      /   __   \         /   __   \        \    \    /    /   *
    *  |    | /    /     |    |     /   /  \   \       /   /  \   \        \    \  /    /    *
    *  |    |/    /      |    |    /    |__|    \     /    |__|    \        \    \/    /     *
    *  |         /       |    |   /              \   /              \        \        /      *
    *  |        /        |    |   |              |   |              |         \      /       *
    *  |        \        |    |   |              |   |              |         /      \       *
    *  |         \       |    |   |     ____     |   |     ____     |        /        \      *
    *  |    |\    \      |    |   |    |    |    |   |    |    |    |       /    /\    \     *
    *  |    | \    \     |    |   |    |    |    |   |    |    |    |      /    /  \    \    *
    *  |    |  \    \    |    |   |    |    |    |   |    |    |    |     /    /    \    \   *
    *  |____|   \____\   |____|   |____|    |____|   |____|    |____|    /____/      \____\  *
    *                                                                                        *       ******************************************************************************************

                                          <?Help File?>

 ____________
/Introduction\___________________________________________________________________________________ -------------------------------------------------------------------------------------------------
PLEASE READ THIS! This file contains information about settings you should have, how to e-mail me, etc. If you don't read this, and the weapon is my pack seems too powerful, or they suck, blame only yourself for not reading this...:o
=================================================================================================

When you download this, inside the zip file, there should be 3 files, one of which is this! So I'll list them here just in case, and how to activate my mod.

<Klaax.iwp> The most important file, the heart of my work! Put this in your Liero directory and activate this using the LieroKit.

<Klaax Weapons> A text file telling you about all the weapons I created. Consult this if you have any problems using the weapons.

<Klaax Readme> That's this file!


 ________
/Settings\_______________________________________________________________________________________
-------------------------------------------------------------------------------------------------
Use this setting for maximum performance of my mod, because I created the mod on this setting, so the weapons will work as they should in this setting.
=================================================================================================
GAME MODE: (Choose yourself, any mode suits my mod well)

LIVES/TIME TO LOSE/FLAGS TO WIN: (Choose one that suits the game you are playing)

LOADING TIME: 100%

MAX BONUSES: 0 (You can also set this to something else, I chose 0 because I hate bonuses                 appearing everytime when I like the weapons that I chose)

NAMES ON BONUSES: OFF (Same as above, choose to your liking)

MAP: OFF (To make the game more challenging)

AMOUNT OF BLOOD: 25% (To speed things up, because some of my weapons scatters a lot of splinters,                      so increasing this will slow things down)

LEVEL: (Any level will do, but not a lousy level :P)

REGENATE LEVEL: YES

SHADOWS: YES

SCREEN SYNC: (Depends on you PC)

LOAD+CHANGE: YES

PLAYER 1 OPTIONS/HEALTH: 200% (A must!)

PLAYER 2 OPTIONS/HEALTH: 200% (Definately!)

WEAPON OPTIONS: (Up to you, make all available, or ban all others other than mine)

^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

 _____________
/Contacting Me\__________________________________________________________________________________
-------------------------------------------------------------------------------------------------
Author: Luo Xinqun
E-Mail: luo_xingqun@nyps.moe.edu.sg

When you want to e-mail me, take note of the following things:

-I greatly welcome suggestions
-Please e-mails me if you find any errors in my mod
-Don't send me crap!
-Please include you name and e-mail address in your e-mail
-Please allow a week for me to reply, or to thank you, cause I don't check my mail every single   day. If I don't response, please forgive me, I must have missed it, wait for a week before   sending me another e-mail. If you are waiting for a thanks, and I didn't send one after one   week, please just consider yourself thanked :)

  Finally, thank you for your time to read this, hope this filed helped you get used to my mod.
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  




                                        