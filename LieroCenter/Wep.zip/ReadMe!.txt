Hello, I am Mr.Darka
Check Out this Cool Weapon - Magic Coin.

By Me.