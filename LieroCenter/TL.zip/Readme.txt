War Zone Weapons Pack
BY: Jayson Gumm
DATE: 4/11/01
WEAPONS INCLUED:

55  MM
AK 47
C4
Cross Bow
Plasma
PP7
Timed Mine

CONTACTING ME:
lierowarzone2@yahoo.com

MY SITE:
Liero War Zone
http://lierowarzone.tsx.org

Thanks for downloading War Zone Weapons Pack.