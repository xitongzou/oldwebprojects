This is a BETA version of LieroKit 1.6.

No documentation is available by now.

Note:
You should always activate Laser and Booby trap Plug-Ins on the Laser or Booby trap or else the weapon will not work like it should.

Disclaimer:
I take no responsibility for any damage this application can cause.